﻿#Accept input parameter
Param
(
    [Parameter(Mandatory = $false)]
    [int]$InactiveDays,
    [switch]$UserMailboxOnly,
    [switch]$ReturnNeverLoggedInMB,
    [string]$UserName,
    [string]$Password
    
)

#Check for MSOnline module
$Modules=Get-Module -Name MSOnline -ListAvailable 
if($Modules.count -eq 0)
{
  Write-Host  Please install MSOnline module using below command: `nInstall-Module MSOnline  -ForegroundColor yellow 
  Exit
}

#Connect AzureAD and Exchange Online from PowerShell 
Get-PSSession | Remove-PSSession 
#Storing credential in script for scheduling purpose
if(($UserName -ne "") -and ($Password -ne ""))
{
  $SecuredPassword = ConvertTo-SecureString -AsPlainText $Password -Force
  $Credential  = New-Object System.Management.Automation.PSCredential $UserName,$SecuredPassword
}
else
{
  $Credential=Get-Credential -Credential $null
}

Connect-MsolService -Credential $Credential #Error will be displayed for MFA enabled accounts
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $Credential -Authentication Basic -AllowRedirection 
Import-PSSession $Session -CommandName Get-Mailbox,Get-MailboxStatistics -FormatTypeName * -AllowClobber | Out-Null

#Set output file 
$ExportCSV=".\LastLogonTimeReport_$((Get-Date -format yyyy-MMM-dd-ddd` hh-mm` tt).ToString()).csv" 
$Result=""  
$Output=@() 
$MBUserCount=0 
$OutputCount=0

#Get friendly name of license plan from external file 
$FriendlyNameHash=Get-Content -Raw -Path .\LicenseFriendlyName.txt -ErrorAction Stop | ConvertFrom-StringData 
(Get-Mailbox) | Where{$_.DisplayName -notlike "Discovery Search Mailbox"} | ForEach-Object{ 
 $upn=$_.UserPrincipalName 
 $LastLogonTime=(Get-MailboxStatistics -Identity $upn).lastlogontime 
 $DisplayName=$_.DisplayName 
 $MBType=$_.RecipientTypeDetails
 $Print=1 
 $MBUserCount++ 
 $RolesAssigned="" 
 Write-Progress -Activity "`n     Processed mailbox count: $MBUserCount "`n"  Currently Processing: $DisplayName" 

 #Retrieve lastlogon time and then calculate Inactive days 
 if($LastLogonTime -eq $null) 
 { 
   $LastLogonTime ="Never Logged In" 
   $InactiveDaysOfUser="-" 
 } 
 else 
 { 
   $InactiveDaysOfUser= (New-TimeSpan -Start $LastLogonTime).Days
 } 

 #Get licenses assigned to mailboxes 
 $User=(Get-MsolUser -UserPrincipalName $upn) 
 $Licenses=$User.Licenses.AccountSkuId 
 $AssignedLicense="" 
 $Count=0

 #Convert license plan to friendly name 
 foreach($License in $Licenses) 
 {  
    $Count++
    $LicenseItem= $License -Split ":" | Select-Object -Last 1  
    $EasyName=$FriendlyNameHash[$LicenseItem]  
    if(!($EasyName))  
    {$NamePrint=$LicenseItem}  
    else  
    {$NamePrint=$EasyName} 
    $AssignedLicense=$AssignedLicense+$NamePrint
    if($count -lt $licenses.count)
    {
      $AssignedLicense=$AssignedLicense+","
    }
 } 
 if($Licenses.count -eq 0) 
 { 
  $AssignedLicense="No License Assigned" 
 }  

 #Inactive days based filter 
 if($InactiveDaysOfUser -ne "-"){ 
 if(($InactiveDays -ne "") -and ([int]$InactiveDays -gt $InactiveDaysOfUser)) 
 { 
  $Print=0 
 }} 

 #License assigned based filter 
 if(($UserMailboxOnly.IsPresent) -and ($MBType -ne "UserMailbox"))
 { 
  $Print=0 
 } 

 #Never Logged In user
 if(($ReturnNeverLoggedInMB.IsPresent) -and ($LastLogonTime -ne "Never Logged In"))
 {
  $Print=0
 }

 #Get roles assigned to user 
 $Roles=(Get-MsolUserRole -UserPrincipalName $upn).Name 
 if($Roles.count -eq 0) 
 { 
  $RolesAssigned="No roles" 
 } 
 else 
 { 
  foreach($Role in $Roles) 
  { 
   $RolesAssigned=$RolesAssigned+$Role 
   if($Roles.indexof($role) -lt (($Roles.count)-1)) 
   { 
    $RolesAssigned=$RolesAssigned+"," 
   } 
  } 
 } 

 #Export result to CSV file 
 if($Print -eq 1) 
 { 
  $OutputCount++
  $Result=@{'UserPrincipalName'=$upn;'DisplayName'=$DisplayName;'LastLogonTime'=$LastLogonTime;'InactiveDays'=$InactiveDaysOfUser;'MailboxType'=$MBType; 'AssignedLicenses'=$AssignedLicense;'Roles'=$RolesAssigned} 
  $Output= New-Object PSObject -Property $Result 
  $Output | Select-Object UserPrincipalName,DisplayName,LastLogonTime,InactiveDays,MailboxType,AssignedLicenses,Roles | Export-Csv -Path $ExportCSV -Notype -Append
 } 
} 

#Open output file after execution 
Write-Host `nScript executed successfully
if((Test-Path -Path $ExportCSV) -eq "True")
{
 Write-Host Result contains $OutputCount mailboxes
 Write-Host "Detailed report available in: $ExportCSV" 
 $Prompt = New-Object -ComObject wscript.shell  
 $UserInput = $Prompt.popup("Do you want to open output file?",`  
 0,"Open Output File",4)  
 If ($UserInput -eq 6)  
 {  
  Invoke-Item "$ExportCSV"  
 } 
}
Else
{
  Write-Host No mailbox found
}
#Clean up session 
Get-PSSession | Remove-PSSession